
(function ($) {
    $.easing['jswing'] = $.easing['swing']; 

    $.extend($.easing,
{
    def: 'easeOutQuad',
    swing: function (x, t, b, c, d) {
        //alert($.easing.default);
        return $.easing[$.easing.def](x, t, b, c, d);
    },
    easeInQuad: function (x, t, b, c, d) {
        return c * (t /= d) * t + b;
    },
    easeOutQuad: function (x, t, b, c, d) {
        return -c * (t /= d) * (t - 2) + b;
    },
    easeInOutQuad: function (x, t, b, c, d) {
        if ((t /= d / 2) < 1) return c / 2 * t * t + b;
        return -c / 2 * ((--t) * (t - 2) - 1) + b;
    },
    easeInCubic: function (x, t, b, c, d) {
        return c * (t /= d) * t * t + b;
    },
    easeOutCubic: function (x, t, b, c, d) {
        return c * ((t = t / d - 1) * t * t + 1) + b;
    },
    easeInOutCubic: function (x, t, b, c, d) {
        if ((t /= d / 2) < 1) return c / 2 * t * t * t + b;
        return c / 2 * ((t -= 2) * t * t + 2) + b;
    },
    easeInQuart: function (x, t, b, c, d) {
        return c * (t /= d) * t * t * t + b;
    },
    easeOutQuart: function (x, t, b, c, d) {
        return -c * ((t = t / d - 1) * t * t * t - 1) + b;
    },
    easeInOutQuart: function (x, t, b, c, d) {
        if ((t /= d / 2) < 1) return c / 2 * t * t * t * t + b;
        return -c / 2 * ((t -= 2) * t * t * t - 2) + b;
    },
    easeInQuint: function (x, t, b, c, d) {
        return c * (t /= d) * t * t * t * t + b;
    },
    easeOutQuint: function (x, t, b, c, d) {
        return c * ((t = t / d - 1) * t * t * t * t + 1) + b;
    },
    easeInOutQuint: function (x, t, b, c, d) {
        if ((t /= d / 2) < 1) return c / 2 * t * t * t * t * t + b;
        return c / 2 * ((t -= 2) * t * t * t * t + 2) + b;
    },
    easeInSine: function (x, t, b, c, d) {
        return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
    },
    easeOutSine: function (x, t, b, c, d) {
        return c * Math.sin(t / d * (Math.PI / 2)) + b;
    },
    easeInOutSine: function (x, t, b, c, d) {
        return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
    },
    easeInExpo: function (x, t, b, c, d) {
        return (t == 0) ? b : c * Math.pow(2, 10 * (t / d - 1)) + b;
    },
    easeOutExpo: function (x, t, b, c, d) {
        return (t == d) ? b + c : c * (-Math.pow(2, -10 * t / d) + 1) + b;
    },
    easeInOutExpo: function (x, t, b, c, d) {
        if (t == 0) return b;
        if (t == d) return b + c;
        if ((t /= d / 2) < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
        return c / 2 * (-Math.pow(2, -10 * --t) + 2) + b;
    },
    easeInCirc: function (x, t, b, c, d) {
        return -c * (Math.sqrt(1 - (t /= d) * t) - 1) + b;
    },
    easeOutCirc: function (x, t, b, c, d) {
        return c * Math.sqrt(1 - (t = t / d - 1) * t) + b;
    },
    easeInOutCirc: function (x, t, b, c, d) {
        if ((t /= d / 2) < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
        return c / 2 * (Math.sqrt(1 - (t -= 2) * t) + 1) + b;
    },
    easeInElastic: function (x, t, b, c, d) {
        var s = 1.70158; var p = 0; var a = c;
        if (t == 0) return b; if ((t /= d) == 1) return b + c; if (!p) p = d * .3;
        if (a < Math.abs(c)) { a = c; var s = p / 4; }
        else var s = p / (2 * Math.PI) * Math.asin(c / a);
        return -(a * Math.pow(2, 10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p)) + b;
    },
    easeOutElastic: function (x, t, b, c, d) {
        var s = 1.70158; var p = 0; var a = c;
        if (t == 0) return b; if ((t /= d) == 1) return b + c; if (!p) p = d * .3;
        if (a < Math.abs(c)) { a = c; var s = p / 4; }
        else var s = p / (2 * Math.PI) * Math.asin(c / a);
        return a * Math.pow(2, -10 * t) * Math.sin((t * d - s) * (2 * Math.PI) / p) + c + b;
    },
    easeInOutElastic: function (x, t, b, c, d) {
        var s = 1.70158; var p = 0; var a = c;
        if (t == 0) return b; if ((t /= d / 2) == 2) return b + c; if (!p) p = d * (.3 * 1.5);
        if (a < Math.abs(c)) { a = c; var s = p / 4; }
        else var s = p / (2 * Math.PI) * Math.asin(c / a);
        if (t < 1) return -.5 * (a * Math.pow(2, 10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p)) + b;
        return a * Math.pow(2, -10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p) * .5 + c + b;
    },
    easeInBack: function (x, t, b, c, d, s) {
        if (s == undefined) s = 1.70158;
        return c * (t /= d) * t * ((s + 1) * t - s) + b;
    },
    easeOutBack: function (x, t, b, c, d, s) {
        if (s == undefined) s = 1.70158;
        return c * ((t = t / d - 1) * t * ((s + 1) * t + s) + 1) + b;
    },
    easeInOutBack: function (x, t, b, c, d, s) {
        if (s == undefined) s = 1.70158;
        if ((t /= d / 2) < 1) return c / 2 * (t * t * (((s *= (1.525)) + 1) * t - s)) + b;
        return c / 2 * ((t -= 2) * t * (((s *= (1.525)) + 1) * t + s) + 2) + b;
    },
    easeInBounce: function (x, t, b, c, d) {
        return c - $.easing.easeOutBounce(x, d - t, 0, c, d) + b;
    },
    easeOutBounce: function (x, t, b, c, d) {
        if ((t /= d) < (1 / 2.75)) {
            return c * (7.5625 * t * t) + b;
        } else if (t < (2 / 2.75)) {
            return c * (7.5625 * (t -= (1.5 / 2.75)) * t + .75) + b;
        } else if (t < (2.5 / 2.75)) {
            return c * (7.5625 * (t -= (2.25 / 2.75)) * t + .9375) + b;
        } else {
            return c * (7.5625 * (t -= (2.625 / 2.75)) * t + .984375) + b;
        }
    },
    easeInOutBounce: function (x, t, b, c, d) {
        if (t < d / 2) return $.easing.easeInBounce(x, t * 2, 0, c, d) * .5 + b;
        return $.easing.easeOutBounce(x, t * 2 - d, 0, c, d) * .5 + c * .5 + b;
    }
});
})(jQuery);



(function ($) {
    $.extend($.easing,
{
    easeIn: function (x, t, b, c, d) {
        return $.easing.easeInQuad(x, t, b, c, d);
    },
    easeOut: function (x, t, b, c, d) {
        return $.easing.easeOutQuad(x, t, b, c, d);
    },
    easeInOut: function (x, t, b, c, d) {
        return $.easing.easeInOutQuad(x, t, b, c, d);
    },
    expoin: function (x, t, b, c, d) {
        return $.easing.easeInExpo(x, t, b, c, d);
    },
    expoout: function (x, t, b, c, d) {
        return $.easing.easeOutExpo(x, t, b, c, d);
    },
    expoinout: function (x, t, b, c, d) {
        return $.easing.easeInOutExpo(x, t, b, c, d);
    },
    bouncein: function (x, t, b, c, d) {
        return $.easing.easeInBounce(x, t, b, c, d);
    },
    bounceout: function (x, t, b, c, d) {
        return $.easing.easeOutBounce(x, t, b, c, d);
    },
    bounceinout: function (x, t, b, c, d) {
        return $.easing.easeInOutBounce(x, t, b, c, d);
    },
    elasin: function (x, t, b, c, d) {
        return $.easing.easeInElastic(x, t, b, c, d);
    },
    elasout: function (x, t, b, c, d) {
        return $.easing.easeOutElastic(x, t, b, c, d);
    },
    elasinout: function (x, t, b, c, d) {
        return $.easing.easeInOutElastic(x, t, b, c, d);
    },
    backin: function (x, t, b, c, d) {
        return $.easing.easeInBack(x, t, b, c, d);
    },
    backout: function (x, t, b, c, d) {
        return $.easing.easeOutBack(x, t, b, c, d);
    },
    backinout: function (x, t, b, c, d) {
        return $.easing.easeInOutBack(x, t, b, c, d);
    }
});
})(jQuery);

function LogoV(){
    return "0.0.4";
}


function getTimeInfo(callback){
    $.ajax({
        type: "POST",
        url: "/App_Services/wsDefault.asmx/GetDateTimeStamp",
        dataType: "json",
        contentType: "application/json;utf-8",
        timeout: 10000,
        error: function () { },
        success: function (data) {
            callback(parseInt(data.d * 1000));
           
        }
    });
  };





$(function(){   
    
    var TH = $('#dual-october-time'),
            HM = $('#hammer-wrap');
    
    
    var THAN = function() {     
          
          TH
          .animate({marginTop:  '50px'  }, 500, 'swing');
          if(isIE()){
              
              // HM.animate({marginTop:  '0'  }, 500, 'easeOutBounce');
              
          }else{
              
              
              HM             
              .transition({
                marginTop: "0" ,
                rotate: '0',
                duration: 500,         
                complete: function() {    
                 
                
                HM.addClass('animated bounceIn');
                    setTimeout(function(){                        
                        clearAnmi();
                        },1000);
                    }
                });         
              
              
             
              
          }
           
           
         
      
      };
      var HMAN = function() {          
         
                 HM.show().css({"marginTop":"-70px",rotate: '-7deg'}).removeClass('animated bounceIn');
                 TH.css({"marginTop":"0px"}).addClass("animated zoomInDown");                  
                
                if(isIE()){
                    // HM.animate({marginTop:  '-50px'  }, 500, 'elasinout');
                    // setTimeout(function (params) {
                    //         THAN();
                    // },500);
                   
                }else{
                    setTimeout(function () {
                         HMTop();
                    },3000)
                   
                }       

      };
      
      var HMTop =function (){
          HM.transition({
                marginTop: "-50px",
                duration: 500,          
                complete: function() {                     
                    THAN();
                }
        }); 
      };
      
      
      var clearAnmi = function(){             
         
          TH.removeClass("animated zoomInDown");
          setTimeout(function () {
              HMINit()
                       // HMAN();
           },2500)
         
      }
   
      var HMINit = function(){
          HM.addClass("animated zoomOut");
          
           setTimeout(function () {             
               HMINitT();
           },500)
      }
      
       var HMINitT = function(){
          HM.removeClass("animated zoomOut").hide();
          
           setTimeout(function () {             
               HMAN();
           },100)
      }
     
      setTimeout(function() {
         //THAN(); 
         TH.show();
         HMAN();
       }, 500);
    
//    var ie = !-[1,]; 
//     alert(ie); 
    
  
      function isIE() { //ie?
            if (!!window.ActiveXObject || "ActiveXObject" in window)
                return true;
            else
                return false;
       }
});
